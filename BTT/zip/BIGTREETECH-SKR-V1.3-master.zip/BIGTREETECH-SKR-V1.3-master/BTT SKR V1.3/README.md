# BIGTREETECH-SKR-V1.3
32bit board with LPC1768, support marlin2.0 and smoothieware, support lcd2004/12864, On-board TMC2130 SPI interface and TMC2208 UART interface no additional wiring is 

BIGTREETECH SKR V1.3 YouTube Video：[here](https://www.youtube.com/watch?v=oaXfXkPYHpw&t=8s)
 
