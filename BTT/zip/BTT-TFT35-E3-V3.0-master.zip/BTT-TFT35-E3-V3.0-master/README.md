# BTT-TFT35-E3-V3.0
BIGTREETECH TFT35-E3 V3.0 is a medium size, dual-mode, ultra-clear 3D printing machine display launched by the 3D printing team of Shenzhen BIGTREE Technology CO., LTD., which can perfectly replace the original LCD screen of Ender3 printer.
